//
//  ViewController1.swift
//  app_demo
//
//  Created by TOPS on 6/14/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController1: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var img2: UIImageView!
    

    @IBOutlet weak var tt1: UITextView!
    
    @IBOutlet weak var tt2: UITextView!
    
    @IBOutlet weak var tt3: UITextView!
    
    @IBOutlet weak var tt4: UITextView!
    
    @IBOutlet weak var tt5: UITextView!
    
    var vimg = UIImage();
    
    var vt1 = String();
    
    var vt2 = String();
    
    var vt3 = String();
    
    var vt4 = String();
    
    var vt5 = String();
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tt1.text = vt1 ;
        
        tt2.text = vt2 ;
        
        tt3.text = vt3 ;
        
        tt4.text = vt4 ;
        
        tt5.text = vt5 ;
        
        img2.image = vimg;

         }
    

    
    
    @IBAction func buttnclk(_ sender: Any) {
        
        
        self.navigationController?.popViewController(animated: true);
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
