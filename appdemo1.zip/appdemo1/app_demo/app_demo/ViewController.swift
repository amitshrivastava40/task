//
//  ViewController.swift
//  app_demo
//
//  Created by TOPS on 6/14/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource{
    
    let arr1 = ["Surat","Vadodara","jamnagar"];
    
    @IBOutlet weak var txt1: UITextField!

    
    @IBOutlet weak var txt2: UITextField!
    
    
    @IBOutlet weak var txt3: UITextField!
    
    
    @IBOutlet weak var txt4: UITextField!
    
    
    @IBOutlet weak var pick: UIDatePicker!
    

    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var picker: UIPickerView!

    @IBOutlet weak var seg: UISegmentedControl!
    
    var dimg1 = String();
    
    var tb1 = String();
    
    var tb2 = String();
    
    var tb3 = String();
    
    var tb4 = String();
    
    var tb5 = String();
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pick.isHidden = true;
        
        picker.isHidden = true;
        
        let dt = Date();
        
        getcurrentdate(dt: dt);
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func getcurrentdate(dt : Date)
    {
        
        let frm = DateFormatter();
        
        frm.dateFormat = "dd-MM-yyyy";
        
        txt3.text = frm.string(from: dt)
        
    }
    
    @IBAction func dpick(_ sender: Any) {
        
        let dt = pick.date ;
        
        getcurrentdate(dt: dt)
        
        pick.isHidden = true;
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return  arr1.count ;
    
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return arr1[row];
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        txt4.text = arr1[row];
        picker.isHidden = true;
    }
    
    func actionsheet(textfield : UITextField)  {
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField.tag == 1
        {
            
            actionsheet(textfield: textField);
            return true;
        }
        
        else if textField.tag == 2
        {
            actionsheet(textfield: textField)
            return true;
        }
            
       else if textField.tag == 3
        {
            pick.isHidden = false;
            return false;
        }
        
        else if(textField.tag == 4)
        {
            picker.isHidden = false;
            return false;
        }
        else
        {
            return false;
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        img.image = img1;
        
        self.dismiss(animated: true, completion: nil);
        
    }
    
    @IBAction func btnclk(_ sender: Any) {
        
        
        let pick = UIImagePickerController();
        
        pick.delegate = self;
        
        let alt = UIAlertController (title: "select", message: "Choose Action", preferredStyle: .actionSheet)
        
        let camera = UIAlertAction(title: "camera", style: .default, handler: {
            
            action in
            
            pick.sourceType = .camera;
            pick.cameraDevice = .front;
            
       
        })
        
        let photolib = UIAlertAction(title: "Photo Library", style: .default, handler: {
        
        action in
            

            pick.sourceType = .photoLibrary;
            
   
        
        })
        
        alt.addAction(camera);
        alt.addAction(photolib);
        
        self.present(pick, animated: true, completion: nil);
        
        
    }
    
    @IBAction func segact(_ sender: Any) {
        
        if seg.selectedSegmentIndex == 0 {
            print("Female");
            
            tb3 = "Female";
            
        }
        
        else if seg.selectedSegmentIndex == 1
        {
            print("Male");
            
            tb3 = "Male";

            
        }
        else
        {
            print("Other");
            
            tb3 = "Other";

        }
        
    }
    
   
    @IBAction func button(_ sender: Any) {
    
 
        
        
        
        let stb = storyboard?.instantiateViewController(withIdentifier: "next") as! ViewController1;
       
        stb.vimg = img.image!;
        
        stb.vt1 = txt1.text!;
        
        stb.vt2 = txt2.text!;
        
        stb.vt3 = tb3;
        
        stb.vt4 = txt3.text!;
        
        stb.vt5 = txt4.text!;
        
        
        self.navigationController?.pushViewController(stb , animated: true);
        
        
        
    
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true);
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

