//
//  ViewController.swift
//  mvcphp
//
//  Created by TOPS on 8/4/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,employeedelgate {

    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    @IBOutlet weak var txtempmob: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func btnclick(_ sender: Any) {
        
        
        let imgdata = UIImageJPEGRepresentation(img.image!, 0.2);
        
        let base64data = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
        
        let obj = employee(emp_id: 0, emp_name: txtempname.text!, emp_add: txtempadd.text!, emp_mob: txtempmob.text!, emp_img: base64data!);
        
    
        
        let objcnt = employeecontroller();
        objcnt.delgate = self;
        objcnt.insertemployeedata(obj: obj);
        
    }
    
    func returnval(stt: String) {
        
        print(stt);
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

