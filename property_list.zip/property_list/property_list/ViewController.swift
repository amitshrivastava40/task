//
//  ViewController.swift
//  property_list
//
//  Created by TOPS on 7/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var finalarr = [Any]();
    

    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
    
    @IBOutlet weak var btnc: UIButton!
    @IBOutlet weak var txt3: UITextField!
    
    @IBAction func btn(_ sender: Any) {
        
        let fmg = FileManager();
        
        if fmg.fileExists(atPath: getpath()) {
            
            
            if btnc.titleLabel?.text == "Update" {
                
            }
            
            var dic = NSDictionary(contentsOfFile: getpath()) as! [String:Any]
            
            var arr = dic["Record"] as! [Any]
            
            let dic1 = ["emp_id": txt1.text!,
                        "emp_name": txt2.text!,
                        "emp_add": txt3.text!]
            
            arr.append(dic1);
            
            dic["Record"] = arr;
            
            let finaldic = NSDictionary(dictionary: dic)
            
            finaldic.write(toFile: getpath(), atomically: true);
            
            finalarr = getdata();
            
    
            
        }
        
  
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        finalarr = getdata();
        
        let fmg = FileManager();
        
        if fmg.fileExists(atPath: getpath()) {
            
            var arr : [[String:String]] = [];
            
            var dic : [String:Any] = ["Record":arr];
            
            let finaldic = NSDictionary(dictionary: dic);
            
            finaldic.write(toFile: getpath(), atomically: true);
            
            
        }
        
      
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return finalarr.count;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tbcell", for: indexPath)
        
        let dic = finalarr[indexPath.section] as! [String:String];
        
        if indexPath.row == 0 {
            
            cell.textLabel?.text = dic["emp_id"];
            
        }
        
        if indexPath.row == 1 {
            
            cell.textLabel?.text = dic["emp_name"];
            
        }
        
        if indexPath.row == 2 {
            
            cell.textLabel?.text = dic["emp_add"];
        }
        
        return cell;
    }
    
    func getpath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let path = arr[0];
        
        let fullpath = path.appending("/student.plist");
        
        print(fullpath);
        
        return fullpath;
    
        
    }
    
    func getdata() -> [Any] {
        
        var arr = [Any]();
        
        let fmg = FileManager();
        
        if fmg.fileExists(atPath: getpath()) {
            var dic = NSDictionary(contentsOfFile: getpath()) as! [String:Any]
            
            arr = dic["Record"] as! [Any]
            
        }
        
        return arr;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

