//
//  ViewController.swift
//  EXAM_3_2
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var LBL1: UILabel!

    @IBOutlet weak var sld: UISlider!
    
    @IBOutlet weak var step: UIStepper!
    
    @IBOutlet weak var lbl2: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func sldact(_ sender: Any) {
        LBL1.text = String(Int(sld.value));
    }
    
    @IBAction func stepact(_ sender: Any) {
        lbl2.text = String(Int(step.value));
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

