//
//  main.swift
//  exam_2
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import Foundation

print("Hello, World!")

class employee {
    func getdata() {
        
    }
    func printdata()  {
        
    }
}
let obj = employee();
obj.getdata();
obj.printdata();



