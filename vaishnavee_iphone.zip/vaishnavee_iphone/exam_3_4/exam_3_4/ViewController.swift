//
//  ViewController.swift
//  exam_3_4
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var seg: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func segact(_ sender: Any) {
        if seg.selectedSegmentIndex == 0 {
            self.view.backgroundColor = UIColor.red;
        }
        else if seg.selectedSegmentIndex == 1
        {
            self.view.backgroundColor = UIColor.green ;
            
        }
        else if seg.selectedSegmentIndex == 2
        {
            self.view.backgroundColor = UIColor.blue;
        }
        else
        {
            self.view.backgroundColor = UIColor.yellow;
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

