//
//  ViewController.swift
//  exam02
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var dpick: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()
        dpick.isHidden = true;
        let dt = Date();
        getcurrentdate(dt: dt);
        // Do any additional setup after loading the view, typically from a nib.
    }
    func getcurrentdate(dt:Date) {
        let mrf = DateFormatter();
        mrf.dateFormat = "yyyy-mm-dd";
        lbl.text = mrf.string(from: dt);
    }

    @IBAction func datepick(_ sender: Any) {
        let  dt  = dpick.date;
        getcurrentdate(dt: dt);
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

