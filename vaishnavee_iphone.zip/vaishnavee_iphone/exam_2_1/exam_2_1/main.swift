//
//  main.swift
//  exam_2_1
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import Foundation

print("Hello, World!")

import Foundation

var dic = ["name":"tops","address":"surat"];
print(dic);

var dic1:[Int:String] = [1:"one",2:"two"];
print(dic1);

for item in dic
{
    print(item);
}

for item1 in dic.keys
{
    print(item1);
}

for item in dic.values
{
    print(item);
    
}

dic["test"]="hello";
print(dic);

dic.removeValue(forKey: "name");
print(dic);
