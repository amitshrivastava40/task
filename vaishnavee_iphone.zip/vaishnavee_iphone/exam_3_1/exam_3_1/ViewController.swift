//
//  ViewController.swift
//  exam_3_1
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnclk(_ sender: Any) {
        
        let alt = UIAlertController(title: "Alert", message: "Enter Details", preferredStyle: .alert)
        
        alt.addTextField { (text1) in
            text1.placeholder = "username";
            
        }
        alt.addTextField{ (text2) in
            text2.placeholder = "password";
            text2.isSecureTextEntry = true;
        
    }
        let ok = UIAlertAction(title: "ok", style: .default, handler: {action in
            print("done");
        })
        alt.addAction(ok);
        
        self.present(alt, animated: true, completion: nil);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

