//
//  ViewController.swift
//  exam_3_3
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate{
    @IBOutlet weak var imgvw: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnclk(_ sender: Any) {
        
        let  pickimg = UIImagePickerController();
        
        pickimg.sourceType = photoLibrary;
        
        self.present(pickimg, animated: true, completion: nil);
        
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage ;
        imgvw.image = img1;
        
        self.dismiss(animated: true, completion: nil);
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

