//
//  common.swift
//  task1
//
//  Created by TOPS on 6/16/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class common: NSObject {
    
    func createtextfield(frm: CGRect,placeholder: String) -> UITextField {
        let txt = UITextField(frame: frm);
        
        txt.placeholder = placeholder;
        
        txt.layer.cornerRadius = 10;
        
        txt.clipsToBounds = true;
        
        txt.layer.borderWidth = 1;
        
        txt.layer.borderColor = UIColor.black.cgColor;
        
        return txt;
        
    }
    
    func createbutton(title: String, frm: CGRect,textcolor: UIColor) -> UIButton {
        
        let btn = UIButton(type: .roundedRect);
        
        btn.frame = frm;
        
        btn.setTitle(title, for: .normal);
        
        btn.tintColor = textcolor;
        
        return btn;
        
        
    }

}
