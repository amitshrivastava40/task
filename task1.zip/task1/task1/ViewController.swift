//
//  ViewController.swift
//  task1
//
//  Created by TOPS on 6/16/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let cmd = common();
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let txtt1 = cmd.createtextfield(frm: CGRect(x:20,y: 80,width: 200,height: 30), placeholder: "firstname");
        
    
        
        self.view.addSubview(txtt1);
        
        let txtt2 = cmd.createtextfield(frm: CGRect(x:20,y: 120,width: 200,height: 30), placeholder: "lastname");
        
        self.view.addSubview(txtt2);
        
        let txtt3 = cmd.createtextfield(frm: CGRect(x:20,y: 160,width: 200,height: 30), placeholder: "gender");
        
        self.view.addSubview(txtt3);
        
        let txtt4 = cmd.createtextfield(frm: CGRect(x:20,y: 200,width: 200,height: 30), placeholder: "city");
        
        self.view.addSubview(txtt4);
        
        let button1 = cmd.createbutton(title: "Submit", frm: CGRect(x:100,y: 250,width: 200,height: 40), textcolor: UIColor.blue)
        
        button1.addTarget(self, action: #selector(self.click), for: .touchUpInside)
        
        self.view.addSubview(button1);
        
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func click(sender: UIButton)  {
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "next")as!ViewController1;
        
        self.navigationController?.pushViewController(stb , animated: true);
        
        
        print("ok");
        
    }
    
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

