//
//  textbox.swift
//  oals
//
//  Created by TOPS on 6/19/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class textbox: UIViewController,UITextFieldDelegate {

     var txt1 = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()

         textfield()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
            }
    

    
    func textfield() {
        let border = CALayer()
        let width = CGFloat(2.0)
        txt1.frame = CGRect(x: 35, y: 35, width: 250, height: 35)
        
        border.borderColor = UIColor.darkGray.cgColor
        border.frame = CGRect(x: 0, y: txt1.frame.size.height - width, width:  txt1.frame.size.width, height: txt1.frame.size.height)
        
        border.borderWidth = width
        txt1.layer.addSublayer(border)
        txt1.layer.masksToBounds = true
        
        
        
        txt1.textAlignment = .left
        txt1.placeholder = "Select"
        txt1.tag = 1
        txt1.delegate = self
        self.view.addSubview(txt1)
        
        
    }
    
    
    }
