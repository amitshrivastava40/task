//
//  ViewController1.swift
//  task1
//
//  Created by TOPS on 6/16/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

let cmd = common();


class ViewController1: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let txt1 = cmd.createtextfield(frm: CGRect(x:20,y: 80,width: 200,height: 30), placeholder: "firstname");
        
        
        self.view.addSubview(txt1);
        
        let txt2 = cmd.createtextfield(frm: CGRect(x:20,y: 120,width: 200,height: 30), placeholder: "lastname");
        
        self.view.addSubview(txt2);
        
        let txt3 = cmd.createtextfield(frm: CGRect(x:20,y: 160,width: 200,height: 30), placeholder: "gender");
        
        self.view.addSubview(txt3);
        
        let txt4 = cmd.createtextfield(frm: CGRect(x:20,y: 200,width: 200,height: 30), placeholder: "city");
        
        self.view.addSubview(txt4);
        
        let button1 = cmd.createbutton(title: "Return", frm: CGRect(x:100,y: 250,width: 200,height: 40), textcolor: UIColor.blue)
        
        button1.addTarget(self, action: #selector(self.click), for: .touchUpInside)
        
        self.view.addSubview(button1);


        // Do any additional setup after loading the view.
    }
    
    func click(sender: UIButton) {
        let stb = self.navigationController?.popViewController(animated: true);
        print("done");
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
