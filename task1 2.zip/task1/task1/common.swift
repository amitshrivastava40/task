//
//  common.swift
//  task1
//
//  Created by TOPS on 6/16/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

 var txt1 = UITextField();

var txt2 = UITextField();


let arr1 = ["Surat","Vadodra","jamnagar"];

class common: NSObject,UIPickerViewDataSource,UIPickerViewDelegate {
    
   
    
    
    func createtextfield(frm: CGRect,placeholder: String) -> UITextField {
        let txt = UITextField(frame: frm);
        
        txt.placeholder = placeholder;
        
        txt.layer.cornerRadius = 10;
        
        txt.clipsToBounds = true;
        
        txt.layer.borderWidth = 1;
        
        txt.layer.borderColor = UIColor.black.cgColor;
        
        return txt;
        
    }
    
    func createbutton(title: String, frm: CGRect,textcolor: UIColor) -> UIButton {
        
        let btn = UIButton(type: .roundedRect);
        
        btn.frame = frm;
        
        btn.setTitle(title, for: .normal);
        
        btn.tintColor = textcolor;
        
        return btn;
        
        
    }

    
    func createdatepicker(frm: CGRect) {
        
        txt1 = UITextField(frame: CGRect(x: 20, y: 200, width: 200, height: 30));
        
        let picker = UIDatePicker(frame: frm);
    
        picker.addTarget(self, action: #selector(self.slct), for: .valueChanged);
        
        picker.datePickerMode = .date ;
        
        txt1.placeholder = "Select Date";
        
        txt1.inputView = picker;
        
        
        
    }
    
    func createsegmentcontrol() -> UISegmentedControl {
        
        let arr = ["Female","Male","Others"];
        
        let seg = UISegmentedControl(items: arr);
        
        seg.frame = CGRect(x: 20, y: 160, width: 200, height: 30)
        
        seg.addTarget(self, action: #selector(self.test), for: .valueChanged);
        
        return seg;
    }
    
    func pickview(frm1: CGRect) -> UIPickerView {
        
         txt2 = UITextField(frame: CGRect(x: 20, y: 240, width: 200, height: 30));
        
        let pick = UIPickerView(frame: frm1);
        
        txt2.placeholder = "Select City";
        
        txt2.inputView = pick;
        
        return pick;
        
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arr1.count;
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arr1[row];
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txt2.text = arr1[row]
    }
    
    
    func test(sender: UISegmentedControl) {
        
        
        
    }
       
    func slct(sender: UIDatePicker) {
        
        let frme = DateFormatter();
        
        frme.dateFormat = "dd-MM-yyyy";
        
        txt1.text = frme.string(from: sender.date);
        
        
        
    }
    
        
}
