//
//  ViewController.swift
//  exam0
//
//  Created by TOPS on 7/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    let arr = ["Gujarat","MP","UP"];
    
    let arr1 = ["surat","ujjain","mathura"];
    
    
    @IBOutlet weak var lbl: UILabel!


    override func viewDidLoad() {
        super.viewDidLoad()
        pickvw.isHidden = false;
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet weak var pickvw: UIPickerView!
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if  component == 0 {
            return arr.count;
        }
        else
        {
            return arr1.count;
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return arr[row];
            
        }
        else
        {
            return arr1[row];
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            lbl.text = arr[row];
            
        }
        else{
            let alt = UIAlertController(title: "Selected City", message: "you have selected", preferredStyle: .alert)
            alt.addTextField(configurationHandler: {
            text1 in
                text1.text = self.arr1[row];
            })
            
                let ok = UIAlertAction(title: "ok", style: .default, handler: {action in
                    print(self.arr1);
                })
                
                    alt.addAction(ok);
                    
                    self.present(alt, animated: true, completion: {action in
                        print("done");
                })
         
            
        }
        
        
            }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

