//
//  ViewController.swift
//  plistdata
//
//  Created by TOPS on 7/5/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var btn: UIButton!
    
    @IBOutlet weak var tbl: UITableView!
    var finalarr : [Any] = [];
    
    @IBOutlet weak var txtempid: UITextField!
    
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        finalarr = getdata();
        
        let fmg = FileManager();
        
        
        if !fmg.fileExists(atPath: getpath()) {
            
            var arr : [[String:String]] = [];
            
            var dic:[String:Any] = ["Record":arr];
            
            let finaldic = NSDictionary(dictionary: dic);
            
            finaldic.write(toFile: getpath(), atomically: true);
        }
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return finalarr.count;
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
         return 3
        
        
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        
        let dic = finalarr[indexPath.section] as! [String:String]
        
        if indexPath.row == 0 {
            
            cell.textLabel?.text = dic["emp_id"];
            
        }
        
        if indexPath.row == 1 {
            
            cell.textLabel?.text = dic["emp_name"];
            
        }
        
        if indexPath.row == 2 {
            
            cell.textLabel?.text = dic["emp_add"];
            
        }
        
        return cell;
        
        
    }
    func getpath() -> String
    {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let path = arr[0];
        
        let fullpath = path.appending("/student.plist");
        
        print(fullpath);
        
        return fullpath;
        
    }
    
    
    func getdata() ->[Any] {
        
        
        var arr = [Any]();
        let fmg = FileManager();
        
        
        if fmg.fileExists(atPath: getpath()) {
            
            var dic = NSDictionary(contentsOfFile: getpath()) as! [String:Any]
            
         arr  = dic["Record"] as! [Any]
        }
        
        return arr;
        
        
    }
    
    @IBAction func btnclick(_ sender: Any) {
        
        
        if btn.titleLabel?.text == "Update" {
            
            
            
            
            
        }
        
        else
        {
        
        
        let fmg = FileManager();
        
        
        if fmg.fileExists(atPath: getpath()) {
            
            var dic = NSDictionary(contentsOfFile: getpath()) as! [String:Any]
            
            var arr = dic["Record"] as! [Any]
            
            let dic1 = ["emp_id":txtempid.text!,"emp_name":txtempname.text!,"emp_add":txtempadd.text!];
            arr.append(dic1);
            
            dic["Record"] = arr;
            
            let finaldic = NSDictionary(dictionary: dic);
            finaldic.write(toFile: getpath(), atomically: true);
            
    
            
            finalarr = getdata();
    
            tbl.reloadData();
            
            print(getpath());
            
        }
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        let dic = finalarr[indexPath.section] as! [String:String]
        
        
        txtempid.text = dic["emp_id"];
        txtempid.isUserInteractionEnabled = false;
        
        txtempname.text = dic["emp_name"];
        txtempadd.text = dic["emp_add"];
        
        btn.setTitle("Update", for: .normal);
        
        
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        
        let dic = finalarr[indexPath.section] as! [String:String]
    
        let emp_id = dic["emp_id"];
        
        
        let fmg = FileManager();
        
        
        if fmg.fileExists(atPath: getpath()) {
            
            var dic = NSDictionary(contentsOfFile: getpath()) as! [String:Any]
            
            var arr = dic["Record"] as! [[String:String]]
            
            var brr = arr;
            
            for i in 0 ... arr.count {
                
                
                var   dic12 = arr[i];
                
                let empid = dic12["emp_id"];
                
                
                
                if empid == emp_id {
                    
                    
                    brr.remove(at: i);
                    
                    break ;
                    }
                	}
           
            dic["Record"] = brr;
            
            let finaldic = NSDictionary(dictionary: dic);
            finaldic.write(toFile: getpath(), atomically: true);
            
            
            
            finalarr = getdata();
            
            tbl.reloadData();

        
        }
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

