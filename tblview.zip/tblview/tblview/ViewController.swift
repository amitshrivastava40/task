//
//  ViewController.swift
//  tblview
//
//  Created by TOPS on 6/26/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit



class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var arr = ["iphone","php","java",".net"]
    
    var img = ["3.jpg","22.jpg","2.jpg","4.jpg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "next", for: indexPath);
        
        cell.textLabel?.text = arr[indexPath.row];
        
        cell.accessoryType = .disclosureIndicator;
        
        cell.imageView?.image = UIImage(named: img[indexPath.row])
        
        return cell;
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(arr[indexPath.row])
    }
    
   func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        arr.remove(at: indexPath.row);
        
        tableView.reloadData();
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        if indexPath.row == 0 {
            return UITableViewCellEditingStyle.none;
        }
        else
        {
            return UITableViewCellEditingStyle.delete;
        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let edit = UITableViewRowAction (style: .default, title: "edit", handler: {action in
        })
        
        let delete = UITableViewRowAction (style: .default, title: "delete", handler: {action in
            
            self.arr.remove(at: indexPath.row)
            
            tableView.reloadData();
        })
        
        return [edit,delete]
    }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return "tops";
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "surat";
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50;
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 60;
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100;
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let  v1 = UIView(frame: CGRect(x: 0,y: 0,width: tableView.frame.size.width,height: 60))
        
        v1.backgroundColor = UIColor.blue;
        
        return v1;
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let  v1 = UIView(frame: CGRect(x: 0,y: 0,width: tableView.frame.size.width,height: 100))
        
        v1.backgroundColor = UIColor.green;
        
        return v1;
    }
 
    
       override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

