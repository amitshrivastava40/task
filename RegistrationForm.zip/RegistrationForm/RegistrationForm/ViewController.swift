//
//  ViewController.swift
//  RegistrationForm
//
//  Created by TOPS on 6/18/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

// regration for validation porpos
let REGEX_NAME = "[A-Za-z]{3,}"
let REGEX_USER_NAME_LIMIT = "^.{3,10}$"
let REGEX_USER_NAME = "[A-Za-z0-9]{3,10}"
let REGEX_EMAIL = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
let REGEX_PASSWORD_LIMIT = "^.{6,20}$"
let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}"
let REGEX_PHONE_DEFAULT = "[0-9]{10}"

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var name: TextFieldValidator!
    @IBOutlet weak var username: TextFieldValidator!
    @IBOutlet weak var password: TextFieldValidator!
    @IBOutlet weak var email: TextFieldValidator!
    @IBOutlet weak var phoneNumber: TextFieldValidator!
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var btn: UIButton!
    var arrIndex:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkFileExist()
        validation()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        // print(path)
        let fullPath = path[0]
        // print(fullPath)
        let finalPath = fullPath.appending("/Information.plist")
        let dic  = NSDictionary(contentsOfFile: finalPath)
        let finalarr = dic?["records"] as! [Any]
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        // print(path)
        let fullPath = path[0]
        // print(fullPath)
        let finalPath = fullPath.appending("/Information.plist")
        let dic  = NSDictionary(contentsOfFile: finalPath)
        var finalarr = dic?["records"] as! [Any]
        var temp = finalarr[indexPath.row] as! [String:Any]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = temp["s_name"] as! String?
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        // print(path)
        let fullPath = path[0]
        // print(fullPath)
        let finalPath = fullPath.appending("/Information.plist")
        let dic  = NSDictionary(contentsOfFile: finalPath)
        var finalarr = dic?["records"] as! [Any]
        var temp = finalarr[indexPath.row] as! [String:Any]
        name.text = temp["s_name"] as! String?
        username.text = temp["s_username"] as! String?
        password.text = temp["s_password"] as! String?
        email.text = temp["s_email"] as! String?
        phoneNumber.text = temp["s_phoneNumber"] as! String?
        btn.setTitle("Update", for: .normal)
        btn.tag = 1
        arrIndex = indexPath.row
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let fullPath = path[0]
        let finalPath = fullPath.appending("/Information.plist")
        let dic  = NSDictionary(contentsOfFile: finalPath)
        var finalarr = dic?["records"] as! [Any]
        finalarr.remove(at: indexPath.row)
        dic?.setValue(finalarr, forKey: "records");
        let dic1 = NSDictionary(dictionary: dic!);
        dic1.write(toFile: finalPath, atomically: true);
        tbl.reloadData()
    }
    
    // check the "plist" file exist or not in Devise
    func checkFileExist() {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        // print(path)
        let fullPath = path[0]
        // print(fullPath)
        let finalPath = fullPath.appending("/Information.plist")
        //print(finalPath)
        if !FileManager().fileExists(atPath: finalPath){
            var dic:[String: Any] = [:];
            var arr:[Any] = [];
            let temp : [String:String] = [:];
            arr.append(temp);
            dic["records"] = arr;
            let dic1 = NSDictionary(dictionary: dic);
            dic1.write(toFile: finalPath, atomically: true);
        }
    }
    
    // Insert Data Into Plist File And store data Permonantly
    func insertDataIntoPlist() {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        let fullpath = path[0] ;
        let finalpath = fullpath.appending("/Information.plist")
        print(finalpath);
        let fmg = FileManager();
        if  fmg.fileExists(atPath: finalpath){
            let dic  = NSDictionary(contentsOfFile: finalpath)
            var finalarr = dic?["records"] as! [Any]
            
            let temp = ["s_id":finalarr.count+1,"s_name":name.text!,"s_username":username.text!,"s_password":password.text!,"s_email":email.text!,"s_phoneNumber":phoneNumber.text!] as [String : Any]
            
            finalarr.append(temp);
            dic?.setValue(finalarr, forKey: "records");
            let dic1 = NSDictionary(dictionary: dic!);
            dic1.write(toFile: finalpath, atomically: true);
        }
    }
    
    // Chack validation
    func validation() {
        name.addRegx(REGEX_NAME, withMsg: "Enter Valid Name")
        name.presentInView = self.view
        
        username.addRegx(REGEX_USER_NAME, withMsg: "Username limit 3 to 10 Character")
        username.presentInView = self.view
        
        password.addRegx(REGEX_PASSWORD_LIMIT, withMsg: "Password Limit 6 to 20 Character")
        password.presentInView = self.view
        
        phoneNumber.addRegx(REGEX_PHONE_DEFAULT, withMsg: "Enter Valid Phone Number")
        phoneNumber.presentInView = self.view
        
        email.addRegx(REGEX_EMAIL, withMsg: "Enter Valid Email-Id")
        email.presentInView = self.view
    }
    
    // conform validation
    func validateData() -> Bool {
        if name.validate() && username.validate() && password.validate() && phoneNumber.validate() && email.validate(){
            return true
        } else {
            return false
        }
    }

    @IBAction func submit(_ sender: Any) {
        
        if validateData() {
            if btn.tag == 1 {
                // Update
                let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
                let fullPath = path[0]
                let finalPath = fullPath.appending("/Information.plist")
                let dic  = NSDictionary(contentsOfFile: finalPath)
                var finalarr = dic?["records"] as! [Any]
                let temp = ["s_id":finalarr.count+1,"s_name":name.text!,"s_username":username.text!,"s_password":password.text!,"s_email":email.text!,"s_phoneNumber":phoneNumber.text!] as [String : Any]
                finalarr.remove(at: arrIndex)
                finalarr.insert(temp, at: arrIndex)
                dic?.setValue(finalarr, forKey: "records");
                let dic1 = NSDictionary(dictionary: dic!);
                dic1.write(toFile: finalPath, atomically: true);
                tbl.reloadData()
                
            } else {
                // Insert
                insertDataIntoPlist()
                tbl.reloadData()
                print("Done")
            }
            btn.tag = 2
            btn.setTitle("Submit", for: .normal)
            name.text = ""
            username.text = ""
            password.text = ""
            email.text = ""
            phoneNumber.text = ""
        } else {
            print("Error")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }


}

