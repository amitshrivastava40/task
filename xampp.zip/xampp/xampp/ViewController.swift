
import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var final_arr : [[String : Any]] = []
    
    var id : String = ""
    
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtaddress: UITextField!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnCommon: UIButton!

    @IBAction func btnclk(_ sender: Any) {
        
        if btnCommon.titleLabel?.text == "Insert" {
            
            InsertData()
        }
        else {
            
            Updatedata(id: id)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
 
        Getdata()
    }

    func ClearData()  {
        
        txtname.text = ""
        txtaddress.text = ""
        txtname.becomeFirstResponder()
    }
    
    func InsertData()  {
        
        let str = "http://localhost/myphp/text.php?Employee_name=\(txtname.text!)&Employee_add=\(txtaddress.text!)";
        
        let url = URL(string: str);
        
        let request = URLRequest(url: url!);
        
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: request) { (data1, req, err1) in
            
            let req = String(data: data1!, encoding: String.Encoding.utf8);
            
            self.Getdata()
        
            self.ClearData()
        }
        
        datatask.resume();
    }
    
    func Getdata()  {
        
        let str = "http://localhost/myphp/getdata.php";
        
        let url = URL(string: str);
        
        let request = URLRequest(url: url!);
        
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: request) { (data1, req, err1) in
            
            let req = String(data: data1!, encoding: String.Encoding.utf8);
            
            DispatchQueue.main.async {
                
                do {
                    
                    let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String  : Any]]
                    
                    //print(jsondata)
                    
                    self.ClearData()
                    
                    self.final_arr = jsondata
                    
                    self.tblView.reloadData()
                    
                }catch {
                    
                }
            }
        }
        
        datatask.resume();

    }
    
    func Updatedata(id : String) {
        
        let str = "http://localhost/myphp/updatedata.php?identity_no=\(id)&Employee_name=\(txtname.text!)&Employee_add=\(txtaddress.text!)";
        
        let url = URL(string: str);
        
        let request = URLRequest(url: url!);
        
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: request) { (data1, req, err1) in
            
            let req = String(data: data1!, encoding: String.Encoding.utf8);
            
            self.Getdata()
        }
        
        datatask.resume();

    }
    
    func Deletedata(id : String)  {
        
        let str = "http://localhost/myphp/deletedata.php?identity_no=\(id)";
        
        let url = URL(string: str);
        
        let request = URLRequest(url: url!);
        
        let session = URLSession.shared;
        
        let datatask = session.dataTask(with: request) { (data1, req, err1) in
            
            let req = String(data: data1!, encoding: String.Encoding.utf8);
            
            self.Getdata()
        }
        
        datatask.resume();
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return final_arr.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        let disc = final_arr[indexPath.section] as! [String : Any]
        
        if indexPath.row == 0 {
            
            cell.textLabel?.text = disc["Employee_name"] as! String?
        }
        if indexPath.row == 1 {
            
            cell.textLabel?.text = disc["Employee_add"] as! String?
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let disc = final_arr[indexPath.section] as! [String : Any]
        
        txtname.text = disc["Employee_name"] as! String?
        id = disc["identity_no"] as! String
        txtaddress.text = disc["Employee_add"] as! String?
        
        btnCommon.setTitle("Update", for: .normal)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let disc = final_arr[indexPath.section] as! [String : Any]
        id = disc["identity_no"] as! String
        
        Deletedata(id: id)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
}

