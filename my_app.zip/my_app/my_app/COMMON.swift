//
//  COMMON.swift
//  my_app
//
//  Created by TOPS on 6/22/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class COMMON: NSObject {
    
  


}
