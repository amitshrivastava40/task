//
//  ViewController.swift
//  my_app
//
//  Created by TOPS on 6/22/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    @IBOutlet weak var txtfname: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        textfieldborder();

        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func textfieldborder()  {
        ///////////////borderfname////////////////
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.purple.cgColor
        border.frame = CGRect(x: 0, y: txtfname.frame.size.height-width, width:txtfname.frame.size.width,height: txtfname.frame.size.height)
        
        border.borderWidth = width
        txtfname.layer.addSublayer(border)
        txtfname.layer.masksToBounds = true
        
        let imgview = UIImageView(frame: CGRect(x: 0, y:0, width: 20, height: 20))
        
        imgview.image = #imageLiteral(resourceName: "img");
        
        txtfname.leftViewMode = .always;
        
        txtfname.leftView = imgview;
        

        

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

