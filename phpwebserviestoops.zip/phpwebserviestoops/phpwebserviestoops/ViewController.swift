//
//  ViewController.swift
//  phpwebserviestoops
//
//  Created by TOPS on 7/26/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var finalarr : [Any] = [];
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtaddress: UITextField!
    
    @IBOutlet weak var txtmob: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        getdata();
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func getdata() {
        
        let url = URL(string: "http://localhost/iosbatch/getdata.php");
        
        let request = URLRequest(url: url!);
        
        let session = URLSession.shared;
        
        let datatsk = session.dataTask(with: request) { (data1, rsp, err) in
            
            if err == nil
            {
             do
            
             {
                
                let jsondata =  try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]];
                
                self.finalarr = jsondata;
                
                DispatchQueue.main.async {
                    
                    self.tbl.reloadData();
                    
                    
                }
                
                
                
            }
                catch
                {
                    
                    
                }
                
                
                
            }
            
            
            
            
            
            
            
        }
        
        datatsk.resume();
        

        
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return finalarr.count;
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return   5;
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        let dic = finalarr[indexPath.section] as! [String:Any];
        
        
        if indexPath.row == 0 {
            
            cell.textLabel?.text = dic["emp_id"] as? String;
            
        }
        if indexPath.row == 1 {
            
            cell.textLabel?.text = dic["emp_name"] as?  String;
            
        }
        if indexPath.row == 2 {
            
            cell.textLabel?.text = dic["emp_add"] as? String;
            
        }
        if indexPath.row == 3 {
            
            cell.textLabel?.text = dic["emp_mob"] as? String;
            
        }
       if indexPath.row == 4
        {
            let strpath = dic["emp_img"] as! String;
            let fullpath = "http://localhost/iosbatch/\(strpath)"
            let imgurl = URL(string: fullpath);
            
            do {
                let dt = try Data(contentsOf: imgurl!)
                
                if dt.count>0  {
                    
                    cell.imageView?.image = UIImage(data: dt);
                    
                    
                    
                }
                
                
            } catch  {
                
                
            }
           
                
                
        }
        
        return cell;
        
        
        
    }
    
    @IBAction func btnclick(_ sender: Any) {
        
        
        let url = URL(string: "http://localhost/iosbatch/indeximage.php")
        
        let imgdata = UIImageJPEGRepresentation(img.image!, 0.2);
        
        
        let base64data = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
        
        
        let dic = ["emp_name":txtempname.text!,"emp_add":txtaddress.text!,"emp_mob":txtmob.text!,"emp_img":base64data!];
        
        do {
            let finalbody = try JSONSerialization.data(withJSONObject: dic, options: []);
            
            
        var request = URLRequest(url: url!);
        request.addValue(String(finalbody.count), forHTTPHeaderField: "Content-Legth")
        ;
        
            request.httpBody = finalbody;
            
        request.httpMethod = "POST";
        
        let session = URLSession.shared;
        
            
        let datatsk = session.dataTask(with: request) { (data1, rsp, err) in
            
          if err == nil
          {
            
            let strresp = String(data: data1!, encoding: String.Encoding.utf8);
            
            
            print(strresp ?? "ok");
            
            

            
            
            
            
            
            
            
            }
            
            
            
            
            
            
            
        }
        
        datatsk.resume();
        
        
        
        
        } catch  {
            
            
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

